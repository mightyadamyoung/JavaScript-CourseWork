/**
 * @author Mitchell Aucoin <mauco29@lsu.edu>
 * Jesse Allison
 * Audio Project 2
 * CSC 2463
 */
var title = "Not So Basic Synthesis";
var intro = "1 = C|2 = D|3 = E|4 = F|5 = G"
var ampEnv;
var osc;
var noisey;
var ampEnvNoise;
var filty;
var lFO;
function setup() {
	createCanvas(200,100);
	lFO = new Tone.LFO(4, -64, 0).start();
	filty = new Tone.Filter(100, "lowpass");
	noisey = new Tone.Noise("pink").start();
	osc = new Tone.Oscillator(440, "sine").start();
	ampEnv = new Tone.AmplitudeEnvelope({
		"attack": 0.1,
		"decay": 0.2,
		"sustain": 1.0,
		"release": 0.8
	}).toMaster();
	ampEnvNoise = new Tone.AmplitudeEnvelope({
		"attack": 0.1,
		"decay": 0.1,
		"sustain": .8,
		"release": 0.1
	}).toMaster();
	osc.connect(ampEnv);
	noisey.connect(filty);
	filty.connect(ampEnvNoise);
	lFO.connect(noisey.volume);
}

function keyPressed() {
	console.log("Key is:", keyCode);
	if (keyCode == 49){
		osc.frequency.value = 'C4';
		ampEnv.triggerAttackRelease(1.0)
		osc.frequency.setValueAtTime('C5', "+0.5");
		ampEnvNoise.triggerAttackRelease(.2, "+0.5");
	} else if (keyCode == 50) {
		osc.frequency.value = 'D4';
		ampEnv.triggerAttackRelease(1.0)
		osc.frequency.setValueAtTime('D5', "+0.5");
		ampEnvNoise.triggerAttackRelease(.2, "+0.5");
	} else if (keyCode == 51) {
		osc.frequency.value = 'E4';
		ampEnv.triggerAttackRelease(1.0)
		osc.frequency.setValueAtTime('E5', "+0.5");
		ampEnvNoise.triggerAttackRelease(.2, "+0.5");
	} else if (keyCode == 52) {
		osc.frequency.value = 'F4';
		ampEnv.triggerAttackRelease(1.0)
		osc.frequency.setValueAtTime('F5', "+0.5");
		ampEnvNoise.triggerAttackRelease(.2, "+0.5");
	} else if (keyCode == 53) {
		osc.frequency.value = 'G4';
		ampEnv.triggerAttackRelease(1.0)
		osc.frequency.setValueAtTime('G5', "+0.5");
		ampEnvNoise.triggerAttackRelease(.2, "+0.5");
	}
}
function draw() {
  fill(255, 0, 0);
  rect(0, 0, width, height);
  fill(0);
  textAlign(10, 10);
  text(title, 10, 50);
  text(intro, 10, 70);
}
