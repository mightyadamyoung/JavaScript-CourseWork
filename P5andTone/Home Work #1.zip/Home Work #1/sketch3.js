//Mitchell Aucoin
//CSC 2463
//Dr. Robert Kooima
//Project 1 Part 3
function setup(){
     createCanvas(500, 250);
     noStroke();
}
function draw(){
     background(0, 0, 0);
     fill(255, 255, 0);
     ellipse(125, 125, 210, 210);
     fill(0, 0, 0);
     triangle(0, 0, 125, 125, 0, 250);
     fill(500, 0, 0);
     ellipse(375, 125, 210, 210);
     rect(270, 125, 210, 105);
     fill(255, 255, 255);
     ellipse(322, 125, 60, 60);
     ellipse(427, 125, 60, 60);
     fill(0, 0, 255);
     ellipse(322, 125, 35, 35);
     ellipse(427, 125, 35, 35);
}
