//Mitchell Aucoin
//CSC 2463
//Dr. Robert Kooima
//Project 1 Part 4
function setup(){
     createCanvas(500, 500);
     strokeWeight(5);
     stroke(255, 255, 255);
}
function draw(){
     clear();
     background(0, 0, 204);
     fill(0, 204, 0);
     ellipse(250, 250, 300, 300);
     fill(255, 0, 0);
     beginShape();
     vertex(250, 90);
     vertex(300, 190);
     vertex(400, 190);
     vertex(320, 270);
     vertex(360, 370);
     vertex(250, 330);
     vertex(140, 370);
     vertex(180, 270);
     vertex(100, 190);
     vertex(200, 190);
     vertex(250, 90);
     endShape();
}
