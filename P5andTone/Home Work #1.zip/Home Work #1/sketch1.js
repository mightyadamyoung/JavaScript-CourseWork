//Mitchell Aucoin
//CSC 2463
//Dr. Robert Kooima
//Project 1 Part 1
function setup(){
     createCanvas(500, 250);
}
function draw(){
     background(0, 255,0);
     ellipse(125, 125, 210, 210);
     rect(260, 20, 210, 210);
}
