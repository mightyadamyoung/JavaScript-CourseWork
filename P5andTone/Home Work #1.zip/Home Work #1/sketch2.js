//Mitchell Aucoin
//CSC 2463
//Dr. Robert Kooima
//Project 1 Part 2
function setup(){
     createCanvas(500, 500);
     noStroke();
}
function draw(){
     clear();
     fill(255, 0, 0, 60);
     ellipse(250, 185, 250, 250);
     fill(0, 255, 0, 60);
     ellipse(340, 345, 250, 250);
     fill(0, 0, 255, 60);
     ellipse(160, 345, 250, 250);

}
