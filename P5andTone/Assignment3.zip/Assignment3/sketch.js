/**
 * @author Mitchell Aucoin <mauco29@lsu.edu>
 * Dr. Robert Kooima
 * Programming Project 3
 * CSC 2463
 */

var guy = [];
var count = 10;

function preload(){
    for (var i = 0; i < count; i++){
        guy[0] = new Walker("56403.png", random(640), random(480));
        guy[1] = new Walker("56405.png", random(640), random(480));
        guy[2] = new Walker("56406.png", random(640), random(480));
        guy[3] = new Walker("56408.png", random(640), random(480));
        guy[4] = new Walker("56409.png", random(640), random(480));
        guy[5] = new Walker("56410.png", random(640), random(480));
        guy[6] = new Walker("56413.png", random(640), random(480));
        guy[7] = new Walker("56425.png", random(640), random(480));
        guy[8] = new Walker("56426.png", random(640), random(480));
        guy[9] = new Walker("56429.png", random(640), random(480));
    }
}
function keyPressed(){
    if(keyCode === RIGHT_ARROW){
        for (var i = 0; i < count; i++){
        guy[i].go(+1);}
    }
    if(keyCode === LEFT_ARROW){
        for (var i = 0; i < count; i++){
        guy[i].go(-1);}
    }
}
function keyReleased(){
    if(keyCode === RIGHT_ARROW){
        for (var i = 0; i < count; i++){
        guy[i].stop();}
    }
    if(keyCode === LEFT_ARROW)
    {
        for(var i = 0; i < count; i++){
        guy[i].stop();}
    }
}
function setup() {
     createCanvas(640, 480);
     imageMode(CENTER);
}

function draw(){
    background(0, 128, 0);
    for (var i = 0; i < count; i ++){
        guy[i].draw();
    }
}
function Walker(imageName, x, y){
    this.spritesheet = loadImage(imageName);
    this.spritesheet;
    this.frame = 0;
    this.x = x;
    this.y = y;
    this.moving = 0;
    this.facing = 0;
    this.draw = function(){
        push();

        translate(this.x, this.y);
        if(this.facing < 0){
            scale(-1.0, 1.0)
        }
        if (this.moving ==0){
            image(this.spritesheet, 0, 0, 80, 80, 0, 0, 80, 80);

        } else {
            if (this.frame == 0)
                image(this.spritesheet, 0, 0, 80, 80, 80, 0, 80, 80);
            if (this.frame == 1)
                image(this.spritesheet, 0, 0, 80, 80, 160, 0, 80, 80);
            if (this.frame == 2)
                image(this.spritesheet, 0, 0, 80, 80, 240, 0, 80, 80);
            if (this.frame == 3)
                image(this.spritesheet, 0, 0, 80, 80, 320, 0, 80, 80);
            if (this.frame == 4)
                image(this.spritesheet, 0, 0, 80, 80, 400, 0, 80, 80);
            if (this.frame == 5)
                image(this.spritesheet, 0, 0, 80, 80, 480, 0, 80, 80);
            if (this.frame == 6)
                image(this.spritesheet, 0, 0, 80, 80, 560, 0, 80, 80);
            if (this.frame == 7)
                image(this.spritesheet, 0, 0, 80, 80, 640, 0, 80, 80);
            if(frameCount % 4 == 0){
                this.frame = (this.frame + 1) % 8;
                this.x = this.x + 6 * this.moving;
                if(this.x < 40 || this.x > width - 40){
                    this.moving = -this.moving;
                    this.facing = -this.facing;
                }
            }
        }
        pop();
    }
    this.stop = function(){
        this.moving = 0;
        this.frame = 3;
    }
    this.go = function (direction){
        this.moving = direction;
        this.facing =direction
    }
}
