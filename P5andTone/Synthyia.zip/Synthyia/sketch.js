/**
 * @author Mitchell Aucoin <mauco29@lsu.edu>
 * Jesse Allison
 * Audio Project 3
 * CSC 2463
 */
var title = "KLaser";
var fmSynth;
var can;

function setup() {
    can = createCanvas(window.innerWidth, window.innerHeight);
    img = loadImage("kanyelaser.jpg");
    img2 = loadImage("kimface.jpg");
    img3 = loadImage("kimface2.png");
    lFO = new Tone.LFO(1, 40, 0).start();
	filty = new Tone.Filter(150, "lowpass");
	noisey = new Tone.Noise("white").start();
	osc = new Tone.Oscillator(440, "sawtooth").start();
	ampEnv = new Tone.AmplitudeEnvelope({
		"attack": 0.5,
		"decay": 0.2,
		"sustain": 1.0,
		"release": 0.8
	}).toMaster();
	ampEnvNoise = new Tone.AmplitudeEnvelope({
		"attack": 0.5,
		"decay": 0.1,
		"sustain": .8,
		"release": 0.1
	}).toMaster();
	osc.connect(ampEnv);
	noisey.connect(filty);
	filty.connect(ampEnvNoise);
	lFO.connect(noisey.volume);
    fmSynth = new Tone.FMSynth().toMaster();
    fmSynth.connect(ampEnv);
    fmSynth.modulationIndex = 5;
}

function mousePressed()
{
    if (mouseX > -1 && mouseX < 1001 && mouseY > -1 && mouseY < 601){
        var mx = mouseX / window.innerWidth;
        fmSynth.harmonicity.value = mx*8.0;
        var my = mouseY / height;
        fmSynth.harmonicity.value = my*8.0;
        fmSynth.frequency.value = "D4";
        fmSynth.triggerAttackRelease("D4", 1.0);
        ampEnv.triggerAttackRelease(1.0);
        ampEnvNoise.triggerAttackRelease(1.0);
        image(img, 0, 0, 1000, 600);
    }
}
function mouseReleased()
{
    can.clear();
}
function draw() {
    image(img2, 855, 450, 150, 150);
    image(img3, 605, 450, 150, 150);
}
