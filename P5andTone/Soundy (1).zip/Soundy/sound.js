/**
 * @author Mitchell Aucoin <mauco29@lsu.edu>
 * Jesse Allison
 * Audio Project 1
 * CSC 2463
 */
var player;
var playButton;
var stopButton;
var playButton2;
var stopButton2;
var playButton3;
var stopButton3;
var playButton4;
var stopButton4;
var dist;
var phaser;
var freeverb;
var chorus;
var distButton1;
var unDistButton1;
var phaserButton1;
var unPhaserButton1;
var verbButton1;
var unVerbButton1;
var chorButton1;
var unChorButton1;
function preload(){
    dist = new Tone.Distortion(.5).toMaster();
    phaser = new Tone.Phaser({
	"frequency" : 15,
	"octaves" : 5,
	"baseFrequency" : 1000
    }).connect(dist);
    freeverb = new Tone.Freeverb().connect(phaser);
    chorus = new Tone.Chorus(4, 2.5, 0.5).connect(freeverb);
    player1 =new Tone.Player("earth.mp3").connect(chorus);
    player2 =new Tone.Player("water.mp3").connect(chorus);
    player3 =new Tone.Player("wind.mp3").connect(chorus);
    player4 =new Tone.Player("fire.mp3").connect(chorus);
}
function setup(){
    dist.wet.value = 0;
    phaser.wet.value = 0;
    freeverb.wet.value = 0;
    freeverb.dampening.value = 1000;
    chorus.wet.value = 0;
    playButton1 = createButton('Earth');
    playButton1.position(19, 19);
    playButton1.mousePressed(play1);
    stopButton1 = createButton('Stop');
    stopButton1.position(19, 39);
    stopButton1.mousePressed(stop1);
    playButton2 = createButton('Water');
    playButton2.position(79, 19);
    playButton2.mousePressed(play2);
    stopButton2 = createButton('Stop');
    stopButton2.position(79, 39);
    stopButton2.mousePressed(stop2);
    playButton3 = createButton('Wind');
    playButton3.position(139, 19);
    playButton3.mousePressed(play3);
    stopButton3 = createButton('Stop');
    stopButton3.position(139, 39);
    stopButton3.mousePressed(stop3);
    playButton4 = createButton('Fire');
    playButton4.position(199, 19);
    playButton4.mousePressed(play4);
    stopButton4 = createButton('Stop');
    stopButton4.position(199, 39);
    stopButton4.mousePressed(stop4);
    distButton1 = createButton('Distort');
    distButton1.position(19, 99);
    distButton1.mousePressed(dist1);
    unDistButton1 = createButton('off');
    unDistButton1.position(19, 119);
    unDistButton1.mousePressed(unDist1);
    phaserButton1 = createButton('Phaser');
    phaserButton1.position(79, 99);
    phaserButton1.mousePressed(phase1);
    unPhaserButton1 = createButton('off');
    unPhaserButton1.position(79, 119);
    unPhaserButton1.mousePressed(unPhase1);
    verbButton1 = createButton('Reverb');
    verbButton1.position(139, 99);
    verbButton1.mousePressed(verb1);
    unVerbButton1 = createButton('off');
    unVerbButton1.position(139, 119);
    unVerbButton1.mousePressed(unVerb1);
    chorButton1 = createButton('Chorus');
    chorButton1.position(199, 99);
    chorButton1.mousePressed(chor1);
    unChorButton1 = createButton('off');
    unChorButton1.position(199, 119);
    unChorButton1.mousePressed(unChor1);

}
function play1(){
    player1.start();
}
function stop1(){
    player1.stop();
}
function play2(){
    player2.start();
}
function stop2(){
    player2.stop();
}
function play3(){
    player3.start();
}
function stop3(){
    player3.stop();
}
function play4(){
    player4.start();
}
function stop4(){
    player4.stop();
}
function dist1(){
    dist.wet.value = 1;
}
function unDist1(){
    dist.wet.value = 0;
}
function phase1(){
    phaser.wet.value = 1;
}
function unPhase1(){
    phaser.wet.value = 0;
}
function verb1(){
    freeverb.wet.value = 1;
}
function unVerb1(){
    freeverb.wet.value = 0;
}
function chor1(){
    chorus.wet.value = 1;
}
function unChor1(){
    chorus.wet.value = 0;
}
