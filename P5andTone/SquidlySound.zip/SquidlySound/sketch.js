/**
 * @author Mitchell Aucoin <mauco29@lsu.edu>
 * Dr. Jessie Ellsison
 * Audio Project 4
 * CSC 2463
 */
var guy = [];
var state = 0;
var squids = 100;
var squished = 0;
var speedMult = 1.2;
var startTime = 0;
var count = 0;
var synth;
var synth2;
var disty;
var phaser;
function preload(){
    for (var i = 0; i < squids; i++){
        guy[i] = new Walker("SquidlyO.png", random(window.innerWidth), random(window.innerHeight));
    }
    phaser = new Tone.Phaser({
	"frequency" : 15,
	"octaves" : 5,
	"baseFrequency" : 1000
    }).toMaster();
    disty = new Tone.Distortion(.5).connect(phaser);
    Tone.Transport.bpm.value = 120;
    Tone.Transport.loop = true;
    Tone.Transport.loopEnd = '4m';
    synth1 = new Tone.PolySynth(4, Tone.Monosynth).connect(phaser);
    synth2 = new Tone.PolySynth(4, Tone.Monosynth).connect(disty);
    synth2.volume.value = -40;
    seq1 = new Tone.Sequence(synthNotes, ['a3', 'b3', 'c3', 'e4', 'e4', 'f4', 'e4', 'd4'], '16n');
    seq2 = new Tone.Sequence(synthNotes, ['a4', 'b4', 'c4', 'e5', 'e5', 'f5', 'e5', 'd5'], '8n');
    seq3 = new Tone.Sequence(synthNotes, ['d5', 'c3', 'g2', 'f3', 'b5', 'b4', 'c3', 'c3'], '8n');
    seq4 = new Tone.Sequence(synthNotes, ['d5','c3'], '2n');
    seq5 = new Tone.Sequence(synthNotes, ['g4', 'a4', 'd4', 'f5', 'b5', 'b5', 'c5', 'c5'], '8n');
    seq6 = new Tone.Sequence(synthNotes, ['g4','c5'], '2n');
    seq7 = new Tone.Sequence(synthNotes, ['a1', 'b2', 'c3'], '16n');
    seq8 = new Tone.Sequence(synthNotes,['a2', 'b2', 'e2', 'f3'], '16n');
    seq9 = new Tone.Sequence(synthNotes, ['a1', 'g1', 'b2', 'f3'], '8n')
    s2seq1 = new Tone.Sequence(synthNotes2, ['a6', 'b6'], '16n');
    player1 = new Tone.Player("squish.mp3").toMaster();
    player1.volume.value = 20;
}
function setup() {
    createCanvas(window.innerWidth, window.innerHeight);
    imageMode(CENTER);
}
function synthNotes(time, note){
    synth1.triggerAttackRelease(note, '8n', time);
}
function synthNotes2(time, note){
    synth2.triggerAttackRelease(note, '8n', time);
}
function draw(){
    background(40, 128, 200);

    if (state == 0){
        fill(255, 0, 0);
        textSize(100);
        textAlign(CENTER);
        text("Squidly Squish!", window.innerWidth/2, window.innerHeight/2);
        textSize(50);
        text("Press Enter to Play", window.innerWidth/2, window.innerHeight/2 + 100);
        Tone.Transport.start();
        seq1.start('8n').stop('4m');
        seq2.start('16n').stop('4m');
        seq8.start('16n').stop('4m');
    }
    else if(state == 1){
        seq1.stop();
        seq2.stop();
        seq8.stop();
        seq3.start('8n').stop('4m');
        seq4.start('2n').stop('4m');
        seq7.start('16n').stop('4m');
        s2seq1.start('16n').stop('4m');
        for (var i = 0; i < squids; i ++){
            guy[i].draw();
        }
        textSize(40);
        text("Timer:", 50, window.innerHeight - 30);
        text(count, 160, window.innerHeight - 30);
        text("Squids Squished:", 400, window.innerHeight - 30);
        text(squished, 600, window.innerHeight - 30);
        startTime = startTime + 1;
        count = (startTime/60).toFixed(2);
        if(count > 10){
            synth2.volume.value = -30;
        }
        if(count > 20){
            synth2.volume.value = -20;
        }
        if(count > 30){
            state = 2;
        }
    }
    else if(state == 2){
        seq3.stop();
        seq4.stop();
        seq7.stop();
        s2seq1.stop();
        seq5.start('8n').stop('4m');
        seq6.start('2n').stop('4m');
        seq9.start('16n').stop('4m');
        startTime = 0;
        textSize(100);
        textAlign(CENTER);
        text("Game Over", window.innerWidth/2, window.innerHeight/2);
        textSize(80);
        text("FinalScore:", window.innerWidth/2 - 60, window.innerHeight/2 + 100);
        text(squished, window.innerWidth/2 + 250, window.innerHeight/2 + 100);
    }
}
function keyPressed(){
    if((keyCode == ENTER)&&(state == 0)){
        state = 1;
    }
}
function mouseClicked(){
    if(state == 1){
        for (var i = 0; i < squids; i ++){
            guy[i].clicked();
        }
    }
}
function Walker(imageName, x, y){
    this.spritesheet = loadImage(imageName);
    this.spritesheet;
    this.frame = 0;
    this.x = x;
    this.y = y;
    this.moving = 1;
    this.facing = 1;
    this.dead = false;
    this.going = true;
    this.draw = function(){
        push();
        this.go();
        translate(this.x, this.y);
        if((this.moving == 0)&&(this.dead == false)){
            image(this.spritesheet, 0, 0, 80, 80, 0, 0, 80, 80);
        }
        if(this.facing < 0){
            scale(-1.0, 1.0)
        } else {
        if (this.frame == 0)
            image(this.spritesheet, 0, 0, 80, 80, 80, 0, 80, 80);
        if (this.frame == 1)
            image(this.spritesheet, 0, 0, 80, 80, 160, 0, 80, 80);
        if (this.frame == 2)
            image(this.spritesheet, 0, 0, 80, 80, 240, 0, 80, 80);
        if (this.frame == 3)
            image(this.spritesheet, 0, 0, 80, 80, 320, 0, 80, 80);
        if (this.frame == 4)
            image(this.spritesheet, 0, 0, 80, 80, 400, 0, 80, 80);
        if (this.frame == 5)
            image(this.spritesheet, 0, 0, 80, 80, 480, 0, 80, 80);
        if (this.frame == 6)
            image(this.spritesheet, 0, 0, 80, 80, 560, 0, 80, 80);
        if (this.frame == 7)
            image(this.spritesheet, 0, 0, 80, 80, 640, 0, 80, 80);
        if(frameCount % 4 == 0 && this.going == true){
            this.frame = (this.frame + 1) % 8;
        } else if ((this.frame == 8) && (this.dead == true)){
            image(this.spritesheet, 0, 0, 80, 80, 720, 0, 80, 80);
        }
    }
    this.x += (speedMult * this.moving);
    pop();
    }
    this.go = function (){
        if(this.x + 40 > width-40){
            this.moving = -1;
            this.facing = -this.facing;
        }
        if(this.x < 40){
            this.moving = 1;
            this.facing = -this.facing;
        }
    }
    this.clicked = function(){
        var d = dist(mouseX, mouseY, this.x, this.y)
        if ((d < 50) && (this.dead == false)){
            player1.start();
            this.frame = 8;
            this.moving = 0;
            this.dead = true;
            this.going = false;
            squished = squished + 1;
        }
        speedMult = speedMult + 0.003;
    }
}
