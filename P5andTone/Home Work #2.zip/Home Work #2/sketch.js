/**
 * @author Mitchell Aucoin <mauco29@lsu.edu>
 * Dr. Robert Kooima
 * Programming Project 2
 * CSC 2463
 */
var r = 255;
var g = 255;
var b = 255;
var strokeSize = 10;

function setup(){
    createCanvas(window.innerWidth, window.innerHeight);
}
function draw(){
    noStroke();
    fill(255, 0, 0);
    rect(0, 0, 20, 20);
    fill(255, 165, 0);
    rect(0, 20, 20, 20);
    fill(255, 255, 0);
    rect(0, 40, 20, 20);
    fill(0, 255, 0);
    rect(0, 60, 20, 20);
    fill(0, 255, 255);
    rect(0, 80, 20, 20);
    fill(0, 0, 255);
    rect(0, 100, 20, 20);
    fill(255, 0, 255);
    rect(0, 120, 20, 20);
    fill(165, 42, 42);
    rect(0, 140, 20, 20);
    fill(255);
    rect(0, 160, 20, 20);
    fill(0);
    rect(0, 180, 20, 20);
    fill(255, 220, 177);
    rect(0, 200, 20, 20);
    fill(259, 194, 152);
    rect(0, 220, 20, 20);
    fill(228, 185, 142);
    rect(0, 240, 20, 20);
    fill(227, 161, 115);
    rect(0, 260, 20, 20);
    fill(204, 132, 67);
    rect(0, 280, 20, 20);
    fill(165, 57, 0);
    rect(0, 300, 20, 20);
    fill(134, 4, 0);
    rect(0, 320, 20, 20);
    fill(68, 0, 0);
    rect(0, 340, 20, 20);
    fill(153);
    rect(0, 360, 20, 20);
    fill(51);
    rect(0, 380, 20, 20);
    fill(255);
    rect(0, 400, 20, 20);
    rect(0, 420, 20, 20);
    rect(0, 440, 20, 20);
    fill(0);
    ellipse(10, 410, 20, 20);
    ellipse(10, 430, 10, 10);
    ellipse(10, 450, 5, 5);
}
function mousePressed(){
    if(mouseX > -1 && mouseX < 21 && mouseY > -1 && mouseY < 21){
        r = 255;
        g = 0;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 20 && mouseY < 41){
        r = 255;
        g = 165;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 40 && mouseY < 61){
        r = 255;
        g = 255;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 60 && mouseY < 81){
        r = 0;
        g = 255;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 80 && mouseY < 101){
        r = 0;
        g = 255;
        b = 255;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 100 && mouseY < 121){
        r = 0;
        g = 0;
        b = 255;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 120 && mouseY < 141){
        r = 255;
        g = 0;
        b = 255;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 140 && mouseY < 161){
        r = 165;
        g = 42;
        b = 42;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY >160 && mouseY < 181){
        r = 255;
        g = 255;
        b = 255;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 180 && mouseY < 201){
        r = 0;
        g = 0;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 200 && mouseY < 221){
        r = 255;
        g = 220;
        b = 177;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 220 && mouseY < 241){
        r = 259;
        g = 194;
        b = 152;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 240 && mouseY < 261){
        r = 228;
        g = 185;
        b = 142;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 260 && mouseY < 281){
        r = 227;
        g = 161;
        b = 115;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 280 && mouseY < 301){
        r = 204;
        g = 132;
        b = 67;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 300 && mouseY < 321){
        r = 165;
        g = 57;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 320 && mouseY < 341){
        r = 134;
        g = 4;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 340 && mouseY < 361){
        r = 68;
        g = 0;
        b = 0;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY >360 && mouseY < 381){
        r = 153;
        g = 153;
        b = 153;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 380 && mouseY < 401){
        r = 51;
        g = 51;
        b = 51;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 400 && mouseY < 421){
        strokeSize = 20;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY >420 && mouseY < 441){
        strokeSize = 10;
    }
    if(mouseX > -1 && mouseX < 21 && mouseY > 440 && mouseY < 461){
        strokeSize = 5;
    }
}
function mouseDragged(){
    strokeWeight(strokeSize);
    stroke(r, g, b);
    line(mouseX, mouseY, pmouseX, pmouseY);
}
